/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA8D1BHECBD
#define BSP_MCU_FEATURE_SET ('B')
#define BSP_ROM_SIZE_BYTES (2064384)
#define BSP_RAM_SIZE_BYTES (917504)
#define BSP_DATA_FLASH_SIZE_BYTES (12288)
#define BSP_PACKAGE_BGA
#define BSP_PACKAGE_PINS (224)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
