################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CREF += \
lab2_aik_ra8d1_uart_da14531mod_project.cref 

MAP += \
lab2_aik_ra8d1_uart_da14531mod_project.map 


# Each subdirectory must supply rules for building sources it contributes

