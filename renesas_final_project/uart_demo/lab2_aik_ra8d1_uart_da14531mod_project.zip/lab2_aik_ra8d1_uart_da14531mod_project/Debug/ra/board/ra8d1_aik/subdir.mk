################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/board/ra8d1_aik/board_init.c \
../ra/board/ra8d1_aik/board_leds.c 

CREF += \
lab2_aik_ra8d1_uart_da14531mod_project.cref 

C_DEPS += \
./ra/board/ra8d1_aik/board_init.d \
./ra/board/ra8d1_aik/board_leds.d 

OBJS += \
./ra/board/ra8d1_aik/board_init.o \
./ra/board/ra8d1_aik/board_leds.o 

MAP += \
lab2_aik_ra8d1_uart_da14531mod_project.map 


# Each subdirectory must supply rules for building sources it contributes
ra/board/ra8d1_aik/%.o: ../ra/board/ra8d1_aik/%.c
	@echo 'Building file: $<'
	$(file > $@.in,-mcpu=cortex-m85 -mthumb -mlittle-endian -mfloat-abi=hard -O0 -ffunction-sections -fdata-sections -fno-strict-aliasing -fmessage-length=0 -funsigned-char -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Waggregate-return -Wno-parentheses-equality -Wfloat-equal -g3 -std=c99 -flax-vector-conversions -fshort-enums -fno-unroll-loops -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\src" -I"." -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra\\fsp\\inc" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra\\fsp\\inc\\api" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra\\fsp\\inc\\instances" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra\\arm\\CMSIS_6\\CMSIS\\Core\\Include" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra_gen" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra_cfg\\fsp_cfg\\bsp" -I"C:\\ra_fsp_v580_workspace\\temp_projects\\lab2_aik_ra8d1_uart_da14531mod_project\\ra_cfg\\fsp_cfg" -D_RENESAS_RA_ -D_RA_CORE=CM85 -D_RA_ORDINAL=1 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -x c "$<" -c -o "$@")
	@clang --target=arm-none-eabi @"$@.in"

