/***********************************************************************************************************************
 * Copyright [2020-2024] Renesas Electronics Corporation and/or its affiliates.  All Rights Reserved.
 *
 * This software and documentation are supplied by Renesas Electronics America Inc. and may only be used with products
 * of Renesas Electronics Corp. and its affiliates ("Renesas").  No other uses are authorized.  Renesas products are
 * sold pursuant to Renesas terms and conditions of sale.  Purchasers are solely responsible for the selection and use
 * of Renesas products and Renesas assumes no liability.  No license, express or implied, to any intellectual property
 * right is granted by Renesas. This software is protected under all applicable laws, including copyright laws. Renesas
 * reserves the right to change or discontinue this software and/or this documentation. THE SOFTWARE AND DOCUMENTATION
 * IS DELIVERED TO YOU "AS IS," AND RENESAS MAKES NO REPRESENTATIONS OR WARRANTIES, AND TO THE FULLEST EXTENT
 * PERMISSIBLE UNDER APPLICABLE LAW, DISCLAIMS ALL WARRANTIES, WHETHER EXPLICITLY OR IMPLICITLY, INCLUDING WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT, WITH RESPECT TO THE SOFTWARE OR
 * DOCUMENTATION.  RENESAS SHALL HAVE NO LIABILITY ARISING OUT OF ANY SECURITY VULNERABILITY OR BREACH.  TO THE MAXIMUM
 * EXTENT PERMITTED BY LAW, IN NO EVENT WILL RENESAS BE LIABLE TO YOU IN CONNECTION WITH THE SOFTWARE OR DOCUMENTATION
 * (OR ANY PERSON OR ENTITY CLAIMING RIGHTS DERIVED FROM YOU) FOR ANY LOSS, DAMAGES, OR CLAIMS WHATSOEVER, INCLUDING,
 * WITHOUT LIMITATION, ANY DIRECT, CONSEQUENTIAL, SPECIAL, INDIRECT, PUNITIVE, OR INCIDENTAL DAMAGES; ANY LOST PROFITS,
 * OTHER ECONOMIC DAMAGE, PROPERTY DAMAGE, OR PERSONAL INJURY; AND EVEN IF RENESAS HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.
 **********************************************************************************************************************/

#include "hal_data.h"
#include "Magic_wand_2class_v01_model.h"

#include <stdio.h>
#include <string.h>

#include "I2C_common/I2C_common.h"
#include "I2C_device_icm42670/i2c_api_icm42670.h"
#include "common_uart/rm_common_uart.h"
#include "SEGGER_RTT.h"

#define APPLY_SOFTMAX  1
static float conf_scores[Magic_wand_2class_v01_NUM_CLASSES];  /* confidence scores */

#define RM_ICM42670_EXAMPLE_IRQ_ENABLE 1

#define RAI_DATA_SHIPPER 0

FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);

//void __attribute__((optimize("O0"))) init_i2c_comm(void) ;

void idleLED();
void inMotionLED();
void blinkDropLED();;
void waveLED();
void circleLED();
void clearLEDs();

FSP_CPP_FOOTER

#define NUM_BUFFS 2
#define BUFF_LEN 512
#define CFG_SYNC_WORD       (0x53534E52) // 'RNSS' backwards
#define BUFFER_LENGTH 100
#define NUM_K_CLASSES 5
#define NUM_S_CLASSES 5

static int count = 0;
float accel_data[(BUFF_LEN+2)* 3];


#if RAI_DATA_SHIPPER

#define DC_DTYPE              float
#define DC_NUM_CHANS          3
#define DC_FRAME_LEN          512

#define RM_ICM42670_EXAMPLE_DELAY_50MS  50
#define RM_ICM42670_EXAMPLE_DELAY_1US   10

extern rai_data_collector_callback_args_t g_callback_args;

static int g_count = 0;
static uint32_t g_events = 0;
static rai_data_collector_frame_buffer_t g_frame_buf[8];
rai_data_collector_callback_args_t g_callback_args;
static DC_DTYPE* p_fb[DC_NUM_CHANS];
static DC_DTYPE g_infer_buffer[DC_FRAME_LEN * DC_NUM_CHANS];

void rai_data_collector0_callback(const rai_data_collector_callback_args_t *p_args);
void rai_data_collector0_error_callback(const rai_data_collector_error_callback_args_t *p_args);
void rai_data_shipper0_callback(rai_data_shipper_callback_args_t *p_args);

static void usb_reset_expiry_timer( void ){
    R_BSP_IrqDisable(GPT2_COUNTER_OVERFLOW_IRQn);
    R_GPT_Stop(&g_timeout_timer2_ctrl);
}

static void usb_start_expiry_timer( void ){
    R_GPT_Stop(&g_timeout_timer2_ctrl);
    R_GPT_Reset(&g_timeout_timer2_ctrl);
    R_GPT_Reset(&g_timeout_timer2_ctrl);
    R_GPT_Start(&g_timeout_timer2_ctrl);
    R_BSP_IrqEnable(GPT2_COUNTER_OVERFLOW_IRQn);
}

#endif

extern uint8_t g_apl_device[];
extern uint8_t g_apl_configuration[];
extern uint8_t g_apl_hs_configuration[];
extern uint8_t g_apl_qualifier_descriptor[];
extern uint8_t *g_apl_string_table[];

#define NUM_STRING_DESCRIPTOR               (7U)
const usb_descriptor_t g_usb_descriptor = {
    g_apl_device,                   /* Pointer to the device descriptor */
    g_apl_configuration,            /* Pointer to the configuration descriptor for Full-speed */
    g_apl_hs_configuration,         /* Pointer to the configuration descriptor for Hi-speed */
    g_apl_qualifier_descriptor,     /* Pointer to the qualifier descriptor */
    g_apl_string_table,             /* Pointer to the string descriptor table */
    NUM_STRING_DESCRIPTOR
};

static bool volatile bBtn1Pressed = 0;
static bool volatile bBtn2Pressed = 0;

/*******************************************************************************************************************//**
 * main() is generated by the RA Configuration editor and is used to generate threads if an RTOS is used.  This function
 * is called by main() when no RTOS is used.
 **********************************************************************************************************************/
void hal_entry(void)
{
    /* TODO: add your own code here */

#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif


    fsp_err_t err = FSP_SUCCESS;
    i2c_api_icm42670_raw_data_t   raw_data;
    i2c_api_icm42670_accel_data_t icm42670_accel_data;
    int prediction = -1;

    #if 0 == RM_ICM42670_EXAMPLE_IRQ_ENABLE
      i2c_api_icm42670_device_status_t device_status;
    #endif

    /* Enable access to the PFS registers. If using r_ioport module then register protection is automatically
     * handled. This code uses BSP IO functions to show how it is used.
     */
    R_BSP_PinAccessEnable ();
    R_BSP_PinWrite(LED1_BLUE, BSP_IO_LEVEL_HIGH);

    /* Open the uart if it is not already open. */
    err = rm_uart_initialize ();
    if ( err != FSP_SUCCESS)
    {
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
    }
    else
    {
        R_BSP_PinWrite(LED1_GREEN, BSP_IO_LEVEL_HIGH);
    }
    R_BSP_PinWrite(LED1_BLUE, BSP_IO_LEVEL_LOW);

    SEGGER_RTT_printf (0, "UART                 : initialized\r\n");

    /* init the i2c comm interface */
    err = i2c_bus1_comon_init();
    if (err != FSP_SUCCESS)
    {
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
        __BKPT(0);
    }
    SEGGER_RTT_printf (0, "I2c common interface : initialized\r\n");


    /* Open ICM42670  open I2C bus and init sensor */
    i2c_api_icm42670_accel_setMode (RM_ICM42670_ACCEL_SENSOR_MODE_LN, 2, 1600);
    err = i2c_api_icm42670_open();
    SEGGER_RTT_printf(0, "sensor ack <WhoAmI>  : 0x%2x\r\n",i2c_api_icm42670_get_who_am_i());


    if (err != FSP_SUCCESS)
    {
        SEGGER_RTT_printf (0, "I2c sensor setup     : failed\r\n");
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
        R_BSP_PinWrite(LED1_GREEN, BSP_IO_LEVEL_LOW);
        R_BSP_PinWrite(LED1_BLUE, BSP_IO_LEVEL_LOW);
        __BKPT(0);
    }
    SEGGER_RTT_printf (0, "I2c ICM42670 setup   : done\r\n");
    /* end */
    {
        i2c_api_icm42670_device_interrupt_cfg_t interrupt_cfg ;
        i2c_api_icm42670_deviceInterruptCfgGet (&interrupt_cfg); //get the recommended settings ;
        //interrupt_cfg.int_config |= 0x01 ; // use active high interrupt
        err =  i2c_api_icm42670_deviceInterruptCfgSet (interrupt_cfg);

        if (err != FSP_SUCCESS)
        {
            R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
            __BKPT(0);
        }
        SEGGER_RTT_printf (0, "ICM42670 interrupts  : initialized\r\n");
    }


   /* Start measurement in data ready mode */
    err = i2c_api_icm42670_measurementStart();
    if (err != FSP_SUCCESS)
    {
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
        __BKPT(0);
    }
    SEGGER_RTT_printf (0, "ICM42670 measurement : started\r\n");

    /* Open external IRQ */
    err = R_ICU_ExternalIrqOpen(&g_external_irq11_pmod1_ctrl, &g_external_irq11_pmod1_cfg);
    if (err != FSP_SUCCESS)
    {
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
        __BKPT(0);
    }
    SEGGER_RTT_printf (0, "ICM42670 interrupt   : opened\r\n");

    err = R_ICU_ExternalIrqEnable (&g_external_irq11_pmod1_ctrl);
    if (err != FSP_SUCCESS)
    {
        R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
        __BKPT(0);
    }
    SEGGER_RTT_printf (0, "ICM42670 interrupt   : enabled\r\n");

    /*
     * Example :
     * Device interrupt : data ready mode
     */

    R_BSP_SoftwareDelay(1500, BSP_DELAY_UNITS_MILLISECONDS);

#if RAI_DATA_SHIPPER // System initialization of the RAI data shipper.

    /* Open Data Collector */
    err = RM_RAI_DATA_COLLECTOR_Open(&g_rai_data_collector0_ctrl, &g_rai_data_collector0_cfg);
    if(err != FSP_SUCCESS){__BKPT(0);}

    /* Open Data Shipper */
    err = RM_RAI_DATA_SHIPPER_Open(&g_rai_data_shipper0_ctrl, &g_rai_data_shipper0_cfg);
    if(err != FSP_SUCCESS){__BKPT(0);}

    /* Get DC frame buffers */
    for(uint8_t k = 0; k < DC_NUM_CHANS; k++)
        RM_RAI_DATA_COLLECTOR_ChannelBufferGet(&g_rai_data_collector0_ctrl, k, (void*)&p_fb[k]);

    /* USB Timeout Timer */
    err = R_GPT_Open(&g_timeout_timer2_ctrl, &g_timeout_timer2_cfg);
    if(err != FSP_SUCCESS){__BKPT(0);}
    err = R_GPT_Enable(&g_timeout_timer2_ctrl);
    if(err != FSP_SUCCESS){__BKPT(0);}

#endif

    err = R_ICU_ExternalIrqOpen(&g_external_irq1_ctrl, &g_external_irq1_cfg);
    err = R_ICU_ExternalIrqEnable(&g_external_irq1_ctrl);

    err = R_ICU_ExternalIrqOpen(&g_external_irq3_ctrl, &g_external_irq3_cfg);
    err = R_ICU_ExternalIrqEnable(&g_external_irq3_ctrl);

    while (true)
    {
      #if RM_ICM42670_EXAMPLE_IRQ_ENABLE
        /* Wait IRQ callback */
        while (0 == g_i2c_api_irq_flag)
        {
            /* Wait callback */
        }
        g_i2c_api_irq_flag = 0;
      #else
        do
        {
           err = i2c_api_icm42670_deviceStatusGet( &device_status );
           if (err != FSP_SUCCESS)
           {
               R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_HIGH);
           }
           else
           {
               R_BSP_PinWrite(LED1_RED, BSP_IO_LEVEL_LOW);
           }
        }
        while (false == device_status.data_ready);
     #endif

#if !RAI_DATA_SHIPPER
        bsp_io_level_t level;
        R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_05_PIN_08, &level);
        if(level == BSP_IO_LEVEL_LOW)
        {
            //SEGGER_RTT_printf(0,"Acquiring data......\n\r");
#endif
            /* Read Accel data */
            err = i2c_api_icm42670_accelRead (&raw_data);

            /* Calculate Accel data */
            err = i2c_api_icm42670_accelDataCalculate (&raw_data, &icm42670_accel_data);
#if !RAI_DATA_SHIPPER
        }
        else count = 0;
#endif

#if RAI_DATA_SHIPPER
        /* Store sample in DC frame buffer */
        p_fb[0][g_count] = icm42670_accel_data.accel_x;
        p_fb[1][g_count] = icm42670_accel_data.accel_y;
        p_fb[2][g_count] = icm42670_accel_data.accel_z;

        /* Inference and Data Shipper */
        if(++g_count >= DC_FRAME_LEN)
        {
            R_ICU_ExternalIrqDisable(&g_external_irq11_pmod1_ctrl);

            /* Copy DC frame buffer to inference buffer */
            DC_DTYPE* p_buf = g_infer_buffer;
            for(uint8_t k = 0; k < DC_NUM_CHANS; k++){
                memcpy(p_buf, p_fb[k], sizeof(DC_DTYPE)*DC_FRAME_LEN);
                RM_RAI_DATA_COLLECTOR_ChannelBufferGet(&g_rai_data_collector0_ctrl, k, (void*)&p_fb[k]);
                p_buf += DC_FRAME_LEN;
            }

            int pred = Magic_wand_2class_v01_predict(g_infer_buffer);
            rai_data_shipper_write_params_t arg;
            arg.diagnostic_data_len = (uint16_t)RealityAI_get_monitor_data_size(get_Magic_wand_2class_v01_model());
            arg.p_diagnostic_data = (uint8_t*)RealityAI_get_monitor_data(get_Magic_wand_2class_v01_model());
            arg.events = (uint16_t)g_events;
            arg.p_sensor_data = &g_callback_args;
            err = g_rai_data_shipper0.p_api->write(&g_rai_data_shipper0_ctrl, &arg);
            if(err != FSP_SUCCESS){
                g_rai_data_collector0.p_api->bufferRelease(&g_rai_data_collector0_ctrl);
            }
            else{
                usb_start_expiry_timer(); // usb write timeout
            }

            g_count = 0;
            g_i2c_api_irq_flag = 0;
            R_ICU_ExternalIrqEnable(&g_external_irq11_pmod1_ctrl);
        }
#else

        /* Continue to accumulate samples. */
#if 0 // For Button test.
        // S3 on AIK-RA8D1.
        if(bBtn1Pressed)
        {
            waveLED();
        }
        // S2 on AIK-RA8D1.
        if(bBtn2Pressed)
        {
            blinkDropLED();
        }
#endif

        if(count < BUFF_LEN){
            accel_data[count] = icm42670_accel_data.accel_x;
            accel_data[count + BUFF_LEN] = icm42670_accel_data.accel_y;
            accel_data[count + (2 * BUFF_LEN)] = icm42670_accel_data.accel_z;
            count++;
        }

        if(count >= BUFF_LEN)
        {
            /* Model prediction */
            Magic_wand_2class_v01_AICLASS AIC = Magic_wand_2class_v01_predict(accel_data);

            /* Convert class score to confidence score (CS) */
            RealityAI_get_class_scores(conf_scores, Magic_wand_2class_v01_NUM_CLASSES, APPLY_SOFTMAX, get_Magic_wand_2class_v01_model());

            /* Decode classification event using class names */
            switch(AIC){
            case(Magic_wand_2class_v01_no_results):
                SEGGER_RTT_printf(0,"No result\n\r");
                clearLEDs();
                break;
            case(Magic_wand_2class_v01_Ascendi):
                SEGGER_RTT_printf(0,"Predicted Class: Ascendi [%.2f]\n", conf_scores[0]);
                circleLED();
                break;
            case(Magic_wand_2class_v01_Descendo):
                SEGGER_RTT_printf(0, "Predicted Class: Descendo [%.2f]\n", conf_scores[1]);
                waveLED();
                break;
            default :
                SEGGER_RTT_printf(0,"DEFAULT\n\r");
                clearLEDs();
                break;
            };
            //blinkDropLED();
            //inMotionLED();
            //waveLED();
            //idleLED();
            //circleLED();
            count = 0;
        }
#endif
    }

}

void clearLEDs(){
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 0); //G
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
}

void idleLED(){
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 1); //G
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
}

void inMotionLED(){
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 1); //G
    R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  1); //B
}

void blinkDropLED(){

    int toggle = 0;

    for(int i = 0; i < 32; i++){
        if(toggle){
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   1); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 0); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
            toggle = 0;
        }
        else{
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 0); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
            toggle = 1;
        }
        R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    }
}

void waveLED(){
    int toggle = 0;
    for(int i = 0; i < 32; i++){
        if(toggle == 1){
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   1); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 0); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
            toggle = 0;
        }
        else if(toggle == 2){
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 1); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
            toggle = 1;
        }
        else{
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   0); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 0); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  1); //B
            toggle = 2;
        }
        R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    }
    clearLEDs();
}

void circleLED(){
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_RED,   1); //R
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_GREEN, 1); //G
            R_IOPORT_PinWrite(&g_ioport_ctrl, LED1_BLUE,  0); //B
}


/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open (&g_ioport_ctrl, &IOPORT_CFG_NAME);
    }
}
#if RAI_DATA_SHIPPER
void gpt_timeout_callback(timer_callback_args_t *p_args){
    (void)p_args;
    // USB write expired, so release buffer to prevent overflow
    g_rai_data_collector0.p_api->bufferRelease(&g_rai_data_collector0_ctrl);
}

// data collector is done, notify main loop
void rai_data_collector0_callback(const rai_data_collector_callback_args_t *p_args){
    g_callback_args.frame_buf_len = p_args->frame_buf_len;
    g_callback_args.frames = p_args->frames;
    g_callback_args.instance_id = p_args->instance_id;
    for(uint8_t i = 0; i < p_args->frames; i++){
        g_frame_buf[i] = p_args->p_frame_buf[i];
    }
    g_callback_args.p_frame_buf = g_frame_buf;
}

void rai_data_collector0_error_callback(const rai_data_collector_error_callback_args_t *p_args){
    (void)p_args;
    __BKPT(0);
}

// data shipper completed transmission of frame
void rai_data_shipper0_callback(rai_data_shipper_callback_args_t *p_args){
    if( p_args->result == RM_COMMS_EVENT_TX_OPERATION_COMPLETE ){
        g_rai_data_collector0.p_api->bufferRelease(&g_rai_data_collector0_ctrl);
        usb_reset_expiry_timer();
    }
}
#endif
#if BSP_TZ_SECURE_BUILD

FSP_CPP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_CPP_FOOTER

#endif
/* Callback function */
void user_btn2_cb(external_irq_callback_args_t *p_args)
{
    /* TODO: add your own code here */
    (void) p_args;
    bBtn2Pressed = 1;
}
/* Callback function */
void user_btn1_cb(external_irq_callback_args_t *p_args)
{
    /* TODO: add your own code here */
    (void) p_args;
    bBtn1Pressed = 1;
    count = 0;
}

