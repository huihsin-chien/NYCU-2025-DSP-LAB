################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/rm_comms_lock/rm_comms_lock.c 

C_DEPS += \
./ra/fsp/src/rm_comms_lock/rm_comms_lock.d 

OBJS += \
./ra/fsp/src/rm_comms_lock/rm_comms_lock.o 

SREC += \
AIK_RA8D1_Asset_Tracking.srec 

MAP += \
AIK_RA8D1_Asset_Tracking.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/rm_comms_lock/%.o: ../ra/fsp/src/rm_comms_lock/%.c
	$(file > $@.in,-mthumb -mfloat-abi=hard -mcpu=cortex-m85+nopacbti -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM85 -D_RA_ORDINAL=1 -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/src" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/src/SEGGER_RTT" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/src/realityai/Magic_wand_2class_v01" -I"." -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/r_usb_basic/src/driver/inc" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -flax-vector-conversions -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

