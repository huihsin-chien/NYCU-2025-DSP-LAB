ra/fsp/src/r_usb_pcdc/src/r_usb_pcdc_driver.o: \
 ../ra/fsp/src/r_usb_pcdc/src/r_usb_pcdc_driver.c \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_version.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/bsp_clock_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_override.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/r_ospi_b_device_types.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_mcu_info.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_elc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_feature.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_peripheral.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_ethernet_phy.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_init.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_leds.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/vector_data.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8D1BH.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_tfu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_sdram.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mmf.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ipc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_features.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_basic_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_basic_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/r_usb_basic/src/driver/inc/r_usb_basic_define.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_pcdc_cfg.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_typedef.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_cstd_rtos.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_typedef.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_basic_define.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_extern.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_pcdc_api.h \
 ../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/hw/inc/r_usb_bitdefine.h
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_version.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/bsp_clock_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_override.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/r_ospi_b_device_types.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_mcu_info.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_elc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_feature.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_peripheral.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/board_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_ethernet_phy.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_init.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_leds.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/vector_data.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8D1BH.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_common.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_tfu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_sdram.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mmf.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ipc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_io.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_security.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_features.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_basic_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_basic_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/r_usb_basic/src/driver/inc/r_usb_basic_define.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_pcdc_cfg.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_typedef.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_cstd_rtos.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_typedef.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_basic_define.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/driver/inc/r_usb_extern.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_pcdc_api.h:
../ra/fsp/src/r_usb_pcdc/src/../../r_usb_basic/src/hw/inc/r_usb_bitdefine.h:
