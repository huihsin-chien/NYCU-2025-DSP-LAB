################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_UPPER_SRCS := 
O_SRCS := 
ELF_SRCS := 
SX_SRCS := 
LINKER_SCRIPT := 
JMP_UPPER_SRCS := 
P_UPPER_SRCS := 
SRC_SRCS := 
JMP_SRCS := 
FSY_UPPER_SRCS := 
PP_UPPER_SRCS := 
OBJ_UPPER_SRCS := 
ASM_SRCS := 
SX_UPPER_SRCS := 
O_UPPER_SRCS := 
S_UPPER_SRCS := 
ELF_UPPER_SRCS := 
C_UPPER_SRCS := 
OBJ_SRCS := 
S_SRCS := 
PP_SRCS := 
SRC_UPPER_SRCS := 
FSY_SRCS := 
P_SRCS := 
C_SRCS := 
JMP_DEPS := 
FSY_DEPS := 
C_UPPER_DEPS := 
SECONDARY_SIZE := 
SRC_UPPER_DEPS := 
P_UPPER_DEPS := 
S_DEPS := 
PP_UPPER_DEPS := 
P_DEPS := 
FSY_UPPER_DEPS := 
C_DEPS := 
SRC_DEPS := 
JMP_UPPER_DEPS := 
PP_DEPS := 
SX_DEPS := 
ASM_UPPER_DEPS := 
SX_UPPER_DEPS := 
OBJS := 
SECONDARY_FLASH := 
ASM_DEPS := 
SREC := 
S_UPPER_DEPS := 
MAP := 

# Every subdirectory with source files must be described here
SUBDIRS := \
ra/board/ra8d1_aik \
ra/fsp/src/bsp/cmsis/Device/RENESAS/Source \
ra/fsp/src/bsp/mcu/all \
ra/fsp/src/bsp/mcu/ra8d1 \
ra/fsp/src/r_dtc \
ra/fsp/src/r_gpt \
ra/fsp/src/r_icu \
ra/fsp/src/r_iic_master \
ra/fsp/src/r_ioport \
ra/fsp/src/r_sci_b_uart \
ra/fsp/src/r_usb_basic \
ra/fsp/src/r_usb_basic/src/driver \
ra/fsp/src/r_usb_basic/src/hw \
ra/fsp/src/r_usb_pcdc/src \
ra/fsp/src/rm_comms_i2c \
ra/fsp/src/rm_comms_lock \
ra/fsp/src/rm_comms_usb_pcdc \
ra/fsp/src/rm_rai_data_collector \
ra/fsp/src/rm_rai_data_shipper \
ra_gen \
src/I2C_common \
src/I2C_device_icm42670 \
src/SEGGER_RTT \
src/common_uart \
src \
src/realityai/Magic_wand_2class_v01 \

