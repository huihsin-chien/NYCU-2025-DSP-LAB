src/realityai/example_classifier.o: ../src/realityai/example_classifier.c \
 ../src/realityai/amr_workshop_model.h ../src/realityai/RealityAI.h \
 ../src/realityai/RealityAI_Config.h ../src/realityai/RealityAI_Types.h
../src/realityai/amr_workshop_model.h:
../src/realityai/RealityAI.h:
../src/realityai/RealityAI_Config.h:
../src/realityai/RealityAI_Types.h:
