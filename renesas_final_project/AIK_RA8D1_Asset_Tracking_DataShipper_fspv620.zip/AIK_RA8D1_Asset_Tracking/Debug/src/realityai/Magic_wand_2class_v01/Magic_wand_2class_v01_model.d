src/realityai/Magic_wand_2class_v01/Magic_wand_2class_v01_model.o: \
 ../src/realityai/Magic_wand_2class_v01/Magic_wand_2class_v01_model.c \
 ../src/realityai/Magic_wand_2class_v01/Magic_wand_2class_v01_model.h \
 ../src/realityai/Magic_wand_2class_v01/RealityAI.h \
 ../src/realityai/Magic_wand_2class_v01/RealityAI_Config.h \
 ../src/realityai/Magic_wand_2class_v01/RealityAI_Types.h
../src/realityai/Magic_wand_2class_v01/Magic_wand_2class_v01_model.h:
../src/realityai/Magic_wand_2class_v01/RealityAI.h:
../src/realityai/Magic_wand_2class_v01/RealityAI_Config.h:
../src/realityai/Magic_wand_2class_v01/RealityAI_Types.h:
