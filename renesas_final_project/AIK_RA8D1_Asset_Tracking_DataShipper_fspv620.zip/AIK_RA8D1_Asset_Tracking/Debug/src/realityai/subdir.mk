################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
SREC += \
AIK_RA8D1_Asset_Tracking.srec 

MAP += \
AIK_RA8D1_Asset_Tracking.map 


# Each subdirectory must supply rules for building sources it contributes

