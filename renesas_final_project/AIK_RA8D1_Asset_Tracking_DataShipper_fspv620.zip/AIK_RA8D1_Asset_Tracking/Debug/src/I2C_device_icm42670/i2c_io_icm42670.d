src/I2C_device_icm42670/i2c_io_icm42670.o: \
 ../src/I2C_device_icm42670/i2c_io_icm42670.c \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/hal_data.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_version.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/bsp_clock_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_override.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/r_ospi_b_device_types.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_mcu_info.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_elc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_feature.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_peripheral.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_ethernet_phy.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_init.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_leds.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/vector_data.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8D1BH.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_tfu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_sdram.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mmf.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ipc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_features.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/common_data.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_icu.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_external_irq_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_rai_data_collector.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_rai_data_collector_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_collector_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_timer_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_basic_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_basic_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/r_usb_basic/src/driver/inc/r_usb_basic_define.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_gpt.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_timer_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/rm_comms_lock/rm_comms_lock.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_comms_usb_pcdc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_pcdc_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_comms_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_comms_usb_pcdc_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_pcdc_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_rai_data_shipper.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_rai_data_shipper_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_shipper_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_crc_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_comms_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_collector_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_dtc.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_dtc_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_iic_master.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_iic_master_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_i2c_master_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_comms_i2c.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_comms_i2c_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_ioport.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_ioport_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_ioport_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_sci_b_uart.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_uart_api.h \
 C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h \
 ../src/I2C_device_icm42670/i2c_io_icm42670.h \
 ../src/I2C_device_icm42670/i2c_api_icm42670.h \
 ../src/I2C_device_icm42670/rm_icm42670_type.h \
 ../src/I2C_device_icm42670/rm_icm42670_reg.h \
 ../src/I2C_device_icm42670/i2c_comm_icm42670_interface.h
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/hal_data.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_version.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/bsp_clock_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_override.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/r_ospi_b_device_types.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_mcu_info.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_elc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_feature.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/ra8d1/bsp_peripheral.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/board_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_ethernet_phy.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_init.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/board/ra8d1_aik/board_leds.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/vector_data.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8D1BH.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_common.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_tfu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_sdram.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mmf.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ipc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_io.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_security.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/fsp_features.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/fsp_common_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_gen/common_data.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_icu.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_external_irq_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/bsp_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_rai_data_collector.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_rai_data_collector_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_collector_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_timer_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_basic_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_basic_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/r_usb_basic/src/driver/inc/r_usb_basic_define.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_gpt.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_timer_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/src/rm_comms_lock/rm_comms_lock.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_comms_usb_pcdc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_usb_basic.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_usb_pcdc_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_comms_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_comms_usb_pcdc_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_usb_pcdc_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_rai_data_shipper.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_rai_data_shipper_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_shipper_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_crc_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_comms_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/rm_rai_data_collector_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_dtc.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_transfer_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_dtc_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_iic_master.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_iic_master_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_i2c_master_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/rm_comms_i2c.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/rm_comms_i2c_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_ioport.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_ioport_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_ioport_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/instances/r_sci_b_uart.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra/fsp/inc/api/r_uart_api.h:
C:/ra_fsp_v620_workspace/AIK_RA8D1_Asset_Tracking/ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h:
../src/I2C_device_icm42670/i2c_io_icm42670.h:
../src/I2C_device_icm42670/i2c_api_icm42670.h:
../src/I2C_device_icm42670/rm_icm42670_type.h:
../src/I2C_device_icm42670/rm_icm42670_reg.h:
../src/I2C_device_icm42670/i2c_comm_icm42670_interface.h:
