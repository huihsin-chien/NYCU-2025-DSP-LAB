/* generated HAL header file - do not edit */
#ifndef HAL_DATA_H_
#define HAL_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "common_data.h"
#include "r_gpt.h"
#include "r_timer_api.h"
#include "rm_comms_i2c.h"
#include "rm_comms_api.h"
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_sci_b_uart.h"
#include "r_uart_api.h"
FSP_HEADER
/** Timer on GPT Instance. */
extern const timer_instance_t g_led_timer1;

/** Access the GPT instance using these structures when calling API functions directly (::p_api is not used). */
extern gpt_instance_ctrl_t g_led_timer1_ctrl;
extern const timer_cfg_t g_led_timer1_cfg;

#ifndef rai_led_timer_callback
void rai_led_timer_callback(timer_callback_args_t *p_args);
#endif
/** Timer on GPT Instance. */
extern const timer_instance_t g_timeout_timer2;

/** Access the GPT instance using these structures when calling API functions directly (::p_api is not used). */
extern gpt_instance_ctrl_t g_timeout_timer2_ctrl;
extern const timer_cfg_t g_timeout_timer2_cfg;

#ifndef gpt_timeout_callback
void gpt_timeout_callback(timer_callback_args_t *p_args);
#endif
/* I2C Communication Device */
extern const rm_comms_instance_t g_comms_i2c_device1;
extern rm_comms_i2c_instance_ctrl_t g_comms_i2c_device1_ctrl;
extern const rm_comms_cfg_t g_comms_i2c_device1_cfg;
#ifndef rm_icm42670_comms_i2c_callback
void rm_icm42670_comms_i2c_callback(rm_comms_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer1;

/** Access the DTC instance using these structures when calling API functions directly (::p_api is not used). */
extern dtc_instance_ctrl_t g_transfer1_ctrl;
extern const transfer_cfg_t g_transfer1_cfg;
/** UART on SCI Instance. */
extern const uart_instance_t g_uart4_jlob;

/** Access the UART instance using these structures when calling API functions directly (::p_api is not used). */
extern sci_b_uart_instance_ctrl_t g_uart4_jlob_ctrl;
extern const uart_cfg_t g_uart4_jlob_cfg;
extern const sci_b_uart_extended_cfg_t g_uart4_jlob_cfg_extend;

#ifndef rm_uart_callback
void rm_uart_callback(uart_callback_args_t *p_args);
#endif
void hal_entry(void);
void g_hal_init(void);
FSP_FOOTER
#endif /* HAL_DATA_H_ */
