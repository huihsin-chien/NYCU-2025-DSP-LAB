/* generated common source file - do not edit */
#include "common_data.h"

icu_instance_ctrl_t g_external_irq3_ctrl;

/** External IRQ extended configuration for ICU HAL driver */
const icu_extended_cfg_t g_external_irq3_ext_cfg =
{ .filter_src = EXTERNAL_IRQ_DIGITAL_FILTER_PCLK_DIV, };

const external_irq_cfg_t g_external_irq3_cfg =
{ .channel = 3, .trigger = EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = true, .clock_source_div =
          EXTERNAL_IRQ_CLOCK_SOURCE_DIV_64,
  .p_callback = user_btn2_cb,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = (void*) &g_external_irq3_ext_cfg,
  .ipl = (2),
#if defined(VECTOR_NUMBER_ICU_IRQ3)
    .irq                 = VECTOR_NUMBER_ICU_IRQ3,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq3 =
{ .p_ctrl = &g_external_irq3_ctrl, .p_cfg = &g_external_irq3_cfg, .p_api = &g_external_irq_on_icu };
icu_instance_ctrl_t g_external_irq1_ctrl;

/** External IRQ extended configuration for ICU HAL driver */
const icu_extended_cfg_t g_external_irq1_ext_cfg =
{ .filter_src = EXTERNAL_IRQ_DIGITAL_FILTER_PCLK_DIV, };

const external_irq_cfg_t g_external_irq1_cfg =
{ .channel = 1, .trigger = EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = true, .clock_source_div =
          EXTERNAL_IRQ_CLOCK_SOURCE_DIV_64,
  .p_callback = user_btn1_cb,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = (void*) &g_external_irq1_ext_cfg,
  .ipl = (12),
#if defined(VECTOR_NUMBER_ICU_IRQ1)
    .irq                 = VECTOR_NUMBER_ICU_IRQ1,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq1 =
{ .p_ctrl = &g_external_irq1_ctrl, .p_cfg = &g_external_irq1_cfg, .p_api = &g_external_irq_on_icu };
#define G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH   (512 * RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE)
#define G_RAI_DATA_COLLECTOR0_CHANNELS  (0 + 3)
#define G_RAI_DATA_COLLECTOR0_VIRT_CHANNELS (3 + 1)

#if 0 > 0
float g_rai_data_collector0_snapshot_channel0_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 1
float g_rai_data_collector0_snapshot_channel1_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 2
float g_rai_data_collector0_snapshot_channel2_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 3
uint8_t g_rai_data_collector0_snapshot_channel3_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 4
uint8_t g_rai_data_collector0_snapshot_channel4_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 5
uint8_t g_rai_data_collector0_snapshot_channel5_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 6
uint8_t g_rai_data_collector0_snapshot_channel6_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 0 > 7
uint8_t g_rai_data_collector0_snapshot_channel7_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 0
float g_rai_data_collector0_data_feed_channel0_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 1
float g_rai_data_collector0_data_feed_channel1_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 2
float g_rai_data_collector0_data_feed_channel2_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 3
uint8_t g_rai_data_collector0_data_feed_channel3_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 4
uint8_t g_rai_data_collector0_data_feed_channel4_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 5
uint8_t g_rai_data_collector0_data_feed_channel5_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 6
uint8_t g_rai_data_collector0_data_feed_channel6_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

#if 3 > 7
uint8_t g_rai_data_collector0_data_feed_channel7_frame_buffer[G_RAI_DATA_COLLECTOR0_PING_PONG_BUFFER_LENGTH] BSP_ALIGN_VARIABLE(RAI_DATA_COLLECTOR_PING_PONG_BUFFER_SIZE * ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 2 : 4));
#endif

rai_data_collector_frame_buffer_t g_rai_data_collector0_frame_buf[G_RAI_DATA_COLLECTOR0_CHANNELS] =
{

#if 3 > 0
  { .p_buf = g_rai_data_collector0_data_feed_channel0_frame_buffer, .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT, },
#endif
#if 3 > 1
  { .p_buf = g_rai_data_collector0_data_feed_channel1_frame_buffer, .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT, },
#endif
#if 3 > 2
  { .p_buf = g_rai_data_collector0_data_feed_channel2_frame_buffer, .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT, },
#endif
#if 3 > 3
    {
        .p_buf = g_rai_data_collector0_data_feed_channel3_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 3 > 4
    {
        .p_buf = g_rai_data_collector0_data_feed_channel4_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 3 > 5
    {
        .p_buf = g_rai_data_collector0_data_feed_channel5_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 3 > 6
    {
        .p_buf = g_rai_data_collector0_data_feed_channel6_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 3 > 7
    {
        .p_buf = g_rai_data_collector0_data_feed_channel7_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif

#if 0 > 0
    {
        .p_buf = g_rai_data_collector0_snapshot_channel0_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT,
    },
#endif
#if 0 > 1
    {
        .p_buf = g_rai_data_collector0_snapshot_channel1_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT,
    },
#endif
#if 0 > 2
    {
        .p_buf = g_rai_data_collector0_snapshot_channel2_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT,
    },
#endif
#if 0 > 3
    {
        .p_buf = g_rai_data_collector0_snapshot_channel3_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 0 > 4
    {
        .p_buf = g_rai_data_collector0_snapshot_channel4_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 0 > 5
    {
        .p_buf = g_rai_data_collector0_snapshot_channel5_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 0 > 6
    {
        .p_buf = g_rai_data_collector0_snapshot_channel6_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
#if 0 > 7
    {
        .p_buf = g_rai_data_collector0_snapshot_channel7_frame_buffer,
        .data_type = RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T,
    },
#endif
        };

#if 0 > 0
transfer_info_t g_rai_data_collector0_info[0] DTC_TRANSFER_INFO_ALIGNMENT =
{

#if 0 > 0
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 1) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel0_frame_buffer,
    },
#endif

#if 0 > 1
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 2) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel1_frame_buffer,
    },
#endif

#if 0 > 2
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 3) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_FLOAT != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel2_frame_buffer,
    },
#endif

#if 0 > 3
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 4) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel3_frame_buffer,
    },
#endif

#if 0 > 4
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 5) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel4_frame_buffer,
    },
#endif

#if 0 > 5
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 6) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel5_frame_buffer,
    },
#endif

#if 0 > 6
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode = (0 == 7) ? TRANSFER_CHAIN_MODE_DISABLED : TRANSFER_CHAIN_MODE_EACH,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel6_frame_buffer,
    },
#endif

#if 0 > 7
    {
        .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.src_addr_mode  = TRANSFER_ADDR_MODE_INCREMENTED,
        .transfer_settings_word_b.repeat_area    = TRANSFER_REPEAT_AREA_SOURCE,
        .transfer_settings_word_b.irq            = TRANSFER_IRQ_END,
        .transfer_settings_word_b.chain_mode =  TRANSFER_CHAIN_MODE_DISABLED,
        .transfer_settings_word_b.mode       = TRANSFER_MODE_BLOCK,
        .p_src      = (void const *) NULL,
        .num_blocks = 1,
        .transfer_settings_word_b.size = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? (transfer_size_t)  ((RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T & RAI_DATA_COLLECTOR_DATA_TYPE_SIZE_MASK) >> 1) : TRANSFER_SIZE_4_BYTE,
        .length     = (RAI_DATA_COLLECTOR_DATA_TYPE_UINT8_T != RAI_DATA_COLLECTOR_DATA_TYPE_DOUBLE) ? 1 : (1 * 2),
        .p_dest     = g_rai_data_collector0_snapshot_channel7_frame_buffer,
    },
#endif
};
#endif

rai_data_collector_frame_buffer_handle_t g_rai_data_collector0_frame_buf_hnd[G_RAI_DATA_COLLECTOR0_VIRT_CHANNELS];

rai_data_collector_extended_cfg_t g_rai_data_collector0_extended_cfg =
{ .p_ping_pong_buf = g_rai_data_collector0_frame_buf, .p_ping_pong_buf_hnd = g_rai_data_collector0_frame_buf_hnd,
#if 0 > 0
    .p_transfer_info = g_rai_data_collector0_info,
#else
  .p_transfer_info = NULL,
#endif
        };

rai_data_collector_instance_ctrl_t g_rai_data_collector0_ctrl;

const rai_data_collector_snapshot_cfg_t g_rai_data_collector0_ss_cfg =
{ .channels = 0, .transfer_len = 1,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_timer = NULL,
#else
    .p_timer = &RA_NOT_DEFINED,
    #endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_transfer = NULL,
#else
    .p_transfer = &RA_NOT_DEFINED,
    #endif
#undef RA_NOT_DEFINED
        };

const rai_data_collector_data_feed_cfg_t g_rai_data_collector0_df_cfg =
{ .channels = 3, };

const rai_data_collector_cfg_t g_rai_data_collector0_cfg =
{ .instance_id = 0, .channels = G_RAI_DATA_COLLECTOR0_CHANNELS, .channel_ready_mask = 7, .virt_channels =
          G_RAI_DATA_COLLECTOR0_VIRT_CHANNELS,
  .required_frame_len = 512, .p_snapshot_cfg = &g_rai_data_collector0_ss_cfg, .p_data_feed_cfg =
          &g_rai_data_collector0_df_cfg,
  .p_extend = &g_rai_data_collector0_extended_cfg, .p_callback = rai_data_collector0_callback, .p_error_callback =
          rai_data_collector0_error_callback,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context = NULL,
#else
  .p_context = (void*) &NULL,
#endif
        };

/* Instance structure to use Data Collector module. */
const rai_data_collector_instance_t g_rai_data_collector0 =
{ .p_ctrl = &g_rai_data_collector0_ctrl, .p_cfg = &g_rai_data_collector0_cfg, .p_api = &g_dc_on_rai_data_collector, };
usb_instance_ctrl_t g_basic0_ctrl;

#if !defined(g_usb_descriptor)
extern usb_descriptor_t g_usb_descriptor;
#endif
#define RA_NOT_DEFINED (1)
const usb_cfg_t g_basic0_cfg =
{ .usb_mode = USB_MODE_PERI,
  .usb_speed = USB_SPEED_FS,
  .module_number = 0,
  .type = USB_CLASS_PCDC,
#if defined(g_usb_descriptor)
                .p_usb_reg = g_usb_descriptor,
#else
  .p_usb_reg = &g_usb_descriptor,
#endif
  .usb_complience_cb = NULL,
#if defined(VECTOR_NUMBER_USBFS_INT)
                .irq       = VECTOR_NUMBER_USBFS_INT,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBFS_RESUME)
                .irq_r     = VECTOR_NUMBER_USBFS_RESUME,
#else
  .irq_r = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBFS_FIFO_0)
                .irq_d0    = VECTOR_NUMBER_USBFS_FIFO_0,
#else
  .irq_d0 = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBFS_FIFO_1)
                .irq_d1    = VECTOR_NUMBER_USBFS_FIFO_1,
#else
  .irq_d1 = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBHS_USB_INT_RESUME)
                .hsirq     = VECTOR_NUMBER_USBHS_USB_INT_RESUME,
#else
  .hsirq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBHS_FIFO_0)
                .hsirq_d0  = VECTOR_NUMBER_USBHS_FIFO_0,
#else
  .hsirq_d0 = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_USBHS_FIFO_1)
                .hsirq_d1  = VECTOR_NUMBER_USBHS_FIFO_1,
#else
  .hsirq_d1 = FSP_INVALID_VECTOR,
#endif
  .ipl = (10),
  .ipl_r = (10),
  .ipl_d0 = (10),
  .ipl_d1 = (10),
  .hsipl = (BSP_IRQ_DISABLED),
  .hsipl_d0 = (BSP_IRQ_DISABLED),
  .hsipl_d1 = (BSP_IRQ_DISABLED),
#if (BSP_CFG_RTOS == 0) && defined(USB_CFG_HMSC_USE)
                .p_usb_apl_callback = NULL,
#else
  .p_usb_apl_callback = NULL,
#endif
#if defined(NULL)
                .p_context = NULL,
#else
  .p_context = (void*) &NULL,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
#else
                .p_transfer_tx = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
#else
                .p_transfer_rx = &RA_NOT_DEFINED,
#endif
        };
#undef RA_NOT_DEFINED

/* Instance structure to use this module. */
const usb_instance_t g_basic0 =
{ .p_ctrl = &g_basic0_ctrl, .p_cfg = &g_basic0_cfg, .p_api = &g_usb_on_usb, };
gpt_instance_ctrl_t g_timer0_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_timer0_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_timer0_extend =
        { .gtioca =
        { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .compare_match_value =
          { /* CMP_A */(uint32_t) 0x0, /* CMP_B */(uint32_t) 0x0 },
          .compare_match_status = (0U << 1U) | 0U, .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE, .capture_filter_gtiocb =
                  GPT_CAPTURE_FILTER_NONE,
#if 0
    .p_pwm_cfg                   = &g_timer0_pwm_extend,
#else
          .p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) false,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif

          .gtioca_polarity = GPT_GTIOC_POLARITY_NORMAL,
          .gtiocb_polarity = GPT_GTIOC_POLARITY_NORMAL, };

const timer_cfg_t g_timer0_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.0005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xea60,
  .duty_cycle_counts = 0x7530, .source_div = (timer_source_div_t) 0, .channel = 0, .p_callback =
          rm_comms_usb_pcdc_timer_handler,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = &g_timer0_extend,
  .cycle_end_ipl = (12),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{ .p_ctrl = &g_timer0_ctrl, .p_cfg = &g_timer0_cfg, .p_api = &g_timer_on_gpt };
/* USB PCDC Communication Device */

rm_comms_usb_pcdc_instance_ctrl_t g_comms_usb_pcdc0_ctrl;

#if BSP_CFG_RTOS == 1 // ThreadX

 #if !defined(NULL)
 rm_comms_mutex_t NULL =
 {
     .p_name = "g_comms_usb_pcdc0 tx mutex",
 };
 #endif

 #if !defined(NULL)
 rm_comms_mutex_t NULL =
 {
     .p_name = "g_comms_usb_pcdc0 rx mutex",
 };
 #endif

 #if !defined(NULL)
 rm_comms_semaphore_t NULL =
 {
     .p_name = "g_comms_usb_pcdc0 tx semaphore",
 };
 #endif

  #if !defined(NULL)
 rm_comms_semaphore_t NULL =
 {
     .p_name = "g_comms_usb_pcdc0 rx semaphore",
 };
 #endif

#elif BSP_CFG_RTOS == 2 // FreeRTOS

#if !defined(NULL)
rm_comms_mutex_t NULL;
#endif

#if !defined(NULL)
rm_comms_mutex_t NULL;
#endif
#if !defined(NULL)
rm_comms_semaphore_t NULL;
#endif

#if !defined(NULL)
rm_comms_semaphore_t NULL;
#endif

#else

#endif

rm_comms_usb_pcdc_extended_cfg_t g_comms_usb_pcdc0_extended_cfg =
{
#if BSP_CFG_RTOS

#if !defined(NULL)
    .p_tx_mutex = &NULL,
#else
    .p_tx_mutex = NULL,
#endif

#if !defined(NULL)
    .p_rx_mutex = &NULL,
#else
    .p_rx_mutex = NULL,
#endif

#if !defined(NULL)
    .p_tx_semaphore = &NULL,
#else
    .p_tx_semaphore = NULL,
#endif

#if !defined(NULL)
    .p_rx_semaphore = &NULL,
#else
    .p_rx_semaphore = NULL,
#endif
    .mutex_timeout  = 0xFFFFFFFF,
#endif
#if BSP_CFG_RTOS == 0
  .p_gpt = &g_timer0,
#endif
  .p_usb = &g_basic0,
  .connect_detection_en = 2, };

const rm_comms_cfg_t g_comms_usb_pcdc0_cfg =
{ .semaphore_timeout = 0xFFFFFFFF,
  .p_lower_level_cfg = NULL,
  .p_extend = (void*) &g_comms_usb_pcdc0_extended_cfg,
  .p_callback = NULL, };

const rm_comms_instance_t g_comms_usb_pcdc0 =
{ .p_ctrl = &g_comms_usb_pcdc0_ctrl, .p_cfg = &g_comms_usb_pcdc0_cfg, .p_api = &g_comms_on_comms_usb_pcdc, };
const rai_data_shipper_cfg_t g_rai_data_shipper0_cfg =
{

#define RA_NOT_DEFINED 1
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_crc = NULL,
#else
    .p_crc = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED

  .p_comms = &g_comms_usb_pcdc0,
  .divider = 0, .p_callback = rai_data_shipper0_callback,
  /* If NULL then do not add & */
#if defined(NULL)
    .p_context = NULL,
#else
  .p_context = (void*) &NULL,
#endif
        };

rai_data_shipper_instance_ctrl_t g_rai_data_shipper0_ctrl;

/* Instance structure to use Data Shipper module. */
const rai_data_shipper_instance_t g_rai_data_shipper0 =
{ .p_ctrl = &g_rai_data_shipper0_ctrl, .p_cfg = &g_rai_data_shipper0_cfg, .p_api = &g_ds_on_rai_data_shipper, };
dtc_instance_ctrl_t g_transfer0_ctrl;

#if (1 == 1)
transfer_info_t g_transfer0_info DTC_TRANSFER_INFO_ALIGNMENT =
{ .transfer_settings_word_b.dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .transfer_settings_word_b.repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .transfer_settings_word_b.irq = TRANSFER_IRQ_END,
  .transfer_settings_word_b.chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .transfer_settings_word_b.src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .transfer_settings_word_b.size = TRANSFER_SIZE_1_BYTE,
  .transfer_settings_word_b.mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = (uint16_t) 0,
  .length = (uint16_t) 0, };

#elif (1 > 1)
/* User is responsible to initialize the array. */
transfer_info_t g_transfer0_info[1] DTC_TRANSFER_INFO_ALIGNMENT;
#else
/* User must call api::reconfigure before enable DTC transfer. */
#endif

const dtc_extended_cfg_t g_transfer0_cfg_extend =
{ .activation_source = VECTOR_NUMBER_IIC1_TXI, };

const transfer_cfg_t g_transfer0_cfg =
{
#if (1 == 1)
  .p_info = &g_transfer0_info,
#elif (1 > 1)
    .p_info              = g_transfer0_info,
#else
    .p_info = NULL,
#endif
  .p_extend = &g_transfer0_cfg_extend, };

/* Instance structure to use this module. */
const transfer_instance_t g_transfer0 =
{ .p_ctrl = &g_transfer0_ctrl, .p_cfg = &g_transfer0_cfg, .p_api = &g_transfer_on_dtc };
iic_master_instance_ctrl_t g_i2c_master1_ctrl;
const iic_master_extended_cfg_t g_i2c_master1_extend =
{ .timeout_mode = IIC_MASTER_TIMEOUT_MODE_SHORT,
  .timeout_scl_low = IIC_MASTER_TIMEOUT_SCL_LOW_ENABLED,
  .smbus_operation = 0,
  /* Actual calculated bitrate: 98945. Actual calculated duty cycle: 51%. */.clock_settings.brl_value = 15,
  .clock_settings.brh_value = 16,
  .clock_settings.cks_value = 4,
  .clock_settings.sddl_value = 0,
  .clock_settings.dlcs_value = 0, };
const i2c_master_cfg_t g_i2c_master1_cfg =
{ .channel = 1, .rate = I2C_MASTER_RATE_STANDARD, .slave = 0x68, .addr_mode = I2C_MASTER_ADDR_MODE_7BIT,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == g_transfer0)
                .p_transfer_tx       = NULL,
#else
  .p_transfer_tx = &g_transfer0,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_transfer_rx = NULL,
#else
                .p_transfer_rx       = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .p_callback = rm_comms_i2c_callback,
  .p_context = NULL,
#if defined(VECTOR_NUMBER_IIC1_RXI)
    .rxi_irq             = VECTOR_NUMBER_IIC1_RXI,
#else
  .rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_TXI)
    .txi_irq             = VECTOR_NUMBER_IIC1_TXI,
#else
  .txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_TEI)
    .tei_irq             = VECTOR_NUMBER_IIC1_TEI,
#else
  .tei_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_IIC1_ERI)
    .eri_irq             = VECTOR_NUMBER_IIC1_ERI,
#else
  .eri_irq = FSP_INVALID_VECTOR,
#endif
  .ipl = (12),
  .p_extend = &g_i2c_master1_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c_master1 =
{ .p_ctrl = &g_i2c_master1_ctrl, .p_cfg = &g_i2c_master1_cfg, .p_api = &g_i2c_master_on_iic };
#if BSP_CFG_RTOS
#if BSP_CFG_RTOS == 1
#if !defined(g_comms_i2c_bus1_recursive_mutex)
TX_MUTEX g_comms_i2c_bus1_recursive_mutex_handle;
CHAR g_comms_i2c_bus1_recursive_mutex_name[] = "g_comms_i2c_bus1 recursive mutex";
#endif
#if !defined(g_comms_i2c_bus1_blocking_semaphore)
TX_SEMAPHORE g_comms_i2c_bus1_blocking_semaphore_handle;
CHAR g_comms_i2c_bus1_blocking_semaphore_name[] = "g_comms_i2c_bus1 blocking semaphore";
#endif
#elif BSP_CFG_RTOS == 2
#if !defined(g_comms_i2c_bus1_recursive_mutex)
SemaphoreHandle_t g_comms_i2c_bus1_recursive_mutex_handle;
StaticSemaphore_t g_comms_i2c_bus1_recursive_mutex_memory;
#endif
#if !defined(g_comms_i2c_bus1_blocking_semaphore)
SemaphoreHandle_t g_comms_i2c_bus1_blocking_semaphore_handle;
StaticSemaphore_t g_comms_i2c_bus1_blocking_semaphore_memory;
#endif
#endif

#if !defined(g_comms_i2c_bus1_recursive_mutex)
/* Recursive Mutex for I2C bus */
rm_comms_i2c_mutex_t g_comms_i2c_bus1_recursive_mutex =
{
    .p_mutex_handle = &g_comms_i2c_bus1_recursive_mutex_handle,
#if BSP_CFG_RTOS == 1 // ThradX
    .p_mutex_name = &g_comms_i2c_bus1_recursive_mutex_name[0],
#elif BSP_CFG_RTOS == 2 // FreeRTOS
    .p_mutex_memory = &g_comms_i2c_bus1_recursive_mutex_memory,
#endif
};
#endif

#if !defined(g_comms_i2c_bus1_blocking_semaphore)
/* Semaphore for blocking */
rm_comms_i2c_semaphore_t g_comms_i2c_bus1_blocking_semaphore =
{
    .p_semaphore_handle = &g_comms_i2c_bus1_blocking_semaphore_handle,
#if BSP_CFG_RTOS == 1 // ThreadX
    .p_semaphore_name = &g_comms_i2c_bus1_blocking_semaphore_name[0],
#elif BSP_CFG_RTOS == 2 // FreeRTOS
    .p_semaphore_memory = &g_comms_i2c_bus1_blocking_semaphore_memory,
#endif
};
#endif
#endif

/* Shared I2C Bus */
#define RA_NOT_DEFINED (1)
rm_comms_i2c_bus_extended_cfg_t g_comms_i2c_bus1_extended_cfg =
{
#if !defined(g_i2c_master1)
  .p_driver_instance = (void*) &g_i2c_master1,
#elif !defined(RA_NOT_DEFINED)
    .p_driver_instance      = (void*)&RA_NOT_DEFINED,
#elif !defined(RA_NOT_DEFINED)
    .p_driver_instance      = (void*)&RA_NOT_DEFINED,
#endif
  .p_current_ctrl = NULL,
  .bus_timeout = 0xFFFFFFFF,
#if BSP_CFG_RTOS
#if !defined(g_comms_i2c_bus1_blocking_semaphore)
    .p_blocking_semaphore = &g_comms_i2c_bus1_blocking_semaphore,
#if !defined(g_comms_i2c_bus1_recursive_mutex)
    .p_bus_recursive_mutex = &g_comms_i2c_bus1_recursive_mutex,
#else
    .p_bus_recursive_mutex = NULL,
#endif
#else
    .p_bus_recursive_mutex = NULL,
    .p_blocking_semaphore = NULL,
#endif
#else
#endif

#if (0)
    .p_elc = (void*)&g_elc,
    .p_timer = (void*)&g_timer,
#else
  .p_elc = NULL,
  .p_timer = NULL,
#endif
        };
#undef RA_NOT_DEFINED
icu_instance_ctrl_t g_external_irq11_pmod1_ctrl;

/** External IRQ extended configuration for ICU HAL driver */
const icu_extended_cfg_t g_external_irq11_pmod1_ext_cfg =
{ .filter_src = EXTERNAL_IRQ_DIGITAL_FILTER_PCLK_DIV, };

const external_irq_cfg_t g_external_irq11_pmod1_cfg =
{ .channel = 11, .trigger = EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = true, .clock_source_div =
          EXTERNAL_IRQ_CLOCK_SOURCE_DIV_32,
  .p_callback = i2c_api_icm42670_irq_callback,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = (void*) &g_external_irq11_pmod1_ext_cfg,
  .ipl = (12),
#if defined(VECTOR_NUMBER_ICU_IRQ11)
    .irq                 = VECTOR_NUMBER_ICU_IRQ11,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq11_pmod1 =
{ .p_ctrl = &g_external_irq11_pmod1_ctrl, .p_cfg = &g_external_irq11_pmod1_cfg, .p_api = &g_external_irq_on_icu };
ioport_instance_ctrl_t g_ioport_ctrl;
const ioport_instance_t g_ioport =
{ .p_api = &g_ioport_on_ioport, .p_ctrl = &g_ioport_ctrl, .p_cfg = &g_bsp_pin_cfg, };

void g_common_init(void)
{
}
