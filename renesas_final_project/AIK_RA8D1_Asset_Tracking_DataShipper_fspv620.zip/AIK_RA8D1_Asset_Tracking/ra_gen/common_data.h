/* generated common header file - do not edit */
#ifndef COMMON_DATA_H_
#define COMMON_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "r_icu.h"
#include "r_external_irq_api.h"
#include "rm_rai_data_collector.h"
#include "r_usb_basic.h"
#include "r_usb_basic_api.h"
#include "r_gpt.h"
#include "r_timer_api.h"
#include "../ra/fsp/src/rm_comms_lock/rm_comms_lock.h"
#include "rm_comms_usb_pcdc.h"
#include "rm_comms_api.h"
#include "rm_rai_data_shipper.h"
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_iic_master.h"
#include "r_i2c_master_api.h"
#include "rm_comms_i2c.h"
#include "rm_comms_api.h"
#include "r_ioport.h"
#include "bsp_pin_cfg.h"
FSP_HEADER
/** External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq3;

/** Access the ICU instance using these structures when calling API functions directly (::p_api is not used). */
extern icu_instance_ctrl_t g_external_irq3_ctrl;
extern const external_irq_cfg_t g_external_irq3_cfg;

#ifndef user_btn2_cb
void user_btn2_cb(external_irq_callback_args_t *p_args);
#endif
/** External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq1;

/** Access the ICU instance using these structures when calling API functions directly (::p_api is not used). */
extern icu_instance_ctrl_t g_external_irq1_ctrl;
extern const external_irq_cfg_t g_external_irq1_cfg;

#ifndef user_btn1_cb
void user_btn1_cb(external_irq_callback_args_t *p_args);
#endif
/* RAI Data Collector Interface */
extern const rai_data_collector_instance_t g_rai_data_collector0;

/** Access the RAI Data Collector instance using these structures
 when calling API functions directly (::p_api is not used). */
extern rai_data_collector_instance_ctrl_t g_rai_data_collector0_ctrl;

extern const rai_data_collector_cfg_t g_rai_data_collector0_cfg;

#ifndef rai_data_collector0_callback
void rai_data_collector0_callback(const rai_data_collector_callback_args_t *p_args);
#endif

#ifndef rai_data_collector0_error_callback
void rai_data_collector0_error_callback(const rai_data_collector_error_callback_args_t *p_args);
#endif

fsp_err_t g_rai_data_collector0_init();
/* Basic on USB Instance. */
extern const usb_instance_t g_basic0;

/** Access the USB instance using these structures when calling API functions directly (::p_api is not used). */
extern usb_instance_ctrl_t g_basic0_ctrl;
extern const usb_cfg_t g_basic0_cfg;

#ifndef NULL
void NULL(void*);
#endif

#if 0 == BSP_CFG_RTOS
#ifndef NULL
void NULL(usb_callback_args_t*);
#endif
#endif

#if 2 == BSP_CFG_RTOS
#ifndef NULL
void NULL(usb_event_info_t *, usb_hdl_t, usb_onoff_t);
#endif
#endif
/** Timer on GPT Instance. */
extern const timer_instance_t g_timer0;

/** Access the GPT instance using these structures when calling API functions directly (::p_api is not used). */
extern gpt_instance_ctrl_t g_timer0_ctrl;
extern const timer_cfg_t g_timer0_cfg;

#ifndef rm_comms_usb_pcdc_timer_handler
void rm_comms_usb_pcdc_timer_handler(timer_callback_args_t *p_args);
#endif
/* USB PCDC Communication Device */
extern const rm_comms_instance_t g_comms_usb_pcdc0;
extern rm_comms_usb_pcdc_instance_ctrl_t g_comms_usb_pcdc0_ctrl;
extern const rm_comms_cfg_t g_comms_usb_pcdc0_cfg;

#ifndef NULL
void NULL(rm_comms_callback_args_t *p_args);
#endif
/* Data Shipper Interface */
extern const rai_data_shipper_instance_t g_rai_data_shipper0;

/** Access the Data Shipper instance using these structures
 when calling API functions directly (::p_api is not used). */
extern rai_data_shipper_instance_ctrl_t g_rai_data_shipper0_ctrl;

extern const rai_data_shipper_cfg_t g_rai_data_shipper0_cfg;

#ifndef rai_data_shipper0_callback
void rai_data_shipper0_callback(rai_data_shipper_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer0;

/** Access the DTC instance using these structures when calling API functions directly (::p_api is not used). */
extern dtc_instance_ctrl_t g_transfer0_ctrl;
extern const transfer_cfg_t g_transfer0_cfg;
/* I2C Master on IIC Instance. */
extern const i2c_master_instance_t g_i2c_master1;

/** Access the I2C Master instance using these structures when calling API functions directly (::p_api is not used). */
extern iic_master_instance_ctrl_t g_i2c_master1_ctrl;
extern const i2c_master_cfg_t g_i2c_master1_cfg;

#ifndef rm_comms_i2c_callback
void rm_comms_i2c_callback(i2c_master_callback_args_t *p_args);
#endif
/* I2C Shared Bus */
extern rm_comms_i2c_bus_extended_cfg_t g_comms_i2c_bus1_extended_cfg;
/** External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq11_pmod1;

/** Access the ICU instance using these structures when calling API functions directly (::p_api is not used). */
extern icu_instance_ctrl_t g_external_irq11_pmod1_ctrl;
extern const external_irq_cfg_t g_external_irq11_pmod1_cfg;

#ifndef i2c_api_icm42670_irq_callback
void i2c_api_icm42670_irq_callback(external_irq_callback_args_t *p_args);
#endif
#define IOPORT_CFG_NAME g_bsp_pin_cfg
#define IOPORT_CFG_OPEN R_IOPORT_Open
#define IOPORT_CFG_CTRL g_ioport_ctrl

/* IOPORT Instance */
extern const ioport_instance_t g_ioport;

/* IOPORT control structure. */
extern ioport_instance_ctrl_t g_ioport_ctrl;
void g_common_init(void);
FSP_FOOTER
#endif /* COMMON_DATA_H_ */
